import React from "react";

const MyBlog = () => {
  return <div>MyBlog</div>;
};

export default MyBlog;
